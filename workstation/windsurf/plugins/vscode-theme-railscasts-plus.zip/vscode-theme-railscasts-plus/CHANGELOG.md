## 0.0.6
- Function argument in italic

## 0.0.5
- Add icon

## 0.0.4
- Fix color Variable
- Fix color Class name
- Fix color Class (definition)

## 0.0.3
- Fix color String interpolation
- Added credits

## 0.0.1
- First release
