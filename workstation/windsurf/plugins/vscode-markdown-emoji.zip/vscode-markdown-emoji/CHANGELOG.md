# Change Log

## 0.3.1 - December 17, 2024
- Small readme fix.

## 0.3.0 - July 15, 2022
- Add notebook support.

## 0.2.1 - September 8, 2021
- Webpack extension.

## 0.2.0 - September 8, 2021
- Add support for running in browsers. 

## 0.1.0 - Feb 22, 2021
- Update to markdown-it-emoji 2.0.0

## 0.0.9 - April 23, 2019
- Remove explicit `extensionKind`. No longer required.

## 0.0.8 - April 18, 2019
- Set explicit `extensionKind` for VS Code compatibility.

## 0.0.7 - November 3, 2017
- Multiroot ready

## 0.0.6 - October 15, 2017
- Update to markdown-it-emoji 1.4.0